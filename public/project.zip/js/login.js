initializeUsers()

async function initializeUsers() {
const password=await hashPassword("bobby");
localStorage.setItem("users", JSON.stringify([ 
    {
        name:"bob",
        email:"bob@gamil,com",
        password:password
    }
])); // Initialize users array if not present
}

async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}


async function registerUser(name, email, password) {
  const users = JSON.parse(localStorage.getItem("users")) || [];

  // Check if user already exists
  if (users.some(u => u.email === email)) {
    alert("Email already registered!");
    return;
  }

  const hashed = await hashPassword(password);
  users.push({ name, email, password: hashed });
  localStorage.setItem("users", JSON.stringify(users));

  alert("Registration successful!");
}

async function loginUser() {
  const userinput = document.getElementById("userinput")
  const passwordinput = document.getElementById("passwordinput")
  const email = userinput.value;
  const password = passwordinput.value;
  const users = JSON.parse(localStorage.getItem("users")) || [];
  const hashed = await hashPassword(password);
  const user = users.find(u => u.email === email && u.password === hashed);

  if (user) {
    localStorage.setItem("loggedInUser", JSON.stringify(user));
    alert(`Welcome back, ${user.name}!`);
    window.location.href = "index.html";
  } else {
    alert("Invalid email or password");
  }
}

function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "login.html";
}

